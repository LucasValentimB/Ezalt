from Ezalt import Ezalt

Ezalt.Ezalt()
